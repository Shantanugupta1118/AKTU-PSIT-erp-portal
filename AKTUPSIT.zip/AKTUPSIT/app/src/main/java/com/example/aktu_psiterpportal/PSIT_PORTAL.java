package com.example.aktu_psiterpportal;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class PSIT_PORTAL extends AppCompatActivity {
    private WebView psiterp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_psit__portal);
        try {

            psiterp = findViewById(R.id.psit_erp);
            WebSettings webSettings = psiterp.getSettings();
            psiterp.setWebViewClient(new WebViewClient());
            webSettings.setDisplayZoomControls(true);
            webSettings.setJavaScriptEnabled(true);
            psiterp.loadUrl("https://erp.psit.in/");

        }
        catch (Exception e){

        }

    }

    @Override
    public void onBackPressed() {
        if (psiterp.canGoBack()) {
            psiterp.goBack();
        }
        else {
            super.onBackPressed();
            }

         }
}

