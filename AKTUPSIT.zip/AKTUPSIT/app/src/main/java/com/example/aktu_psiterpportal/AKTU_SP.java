package com.example.aktu_psiterpportal;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class AKTU_SP extends AppCompatActivity {
    private WebView sp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);
        setContentView(R.layout.activity_aktu__sp);
        sp = (WebView)findViewById(R.id.aktu_sp_web);
        WebSettings webSettings = sp.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDisplayZoomControls(true);
        sp.loadUrl("https://erp.aktu.ac.in/WebPages/Public/Students/Dashboard.aspx");
        sp.setWebViewClient(new WebViewClient());

    }

    @Override
    public void onBackPressed() {
        if (sp.canGoBack()) {
            sp.goBack();
        }
        else {
            super.onBackPressed();
        }
    }
}
