package com.example.aktu_psiterpportal;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class AKTU_ERP extends AppCompatActivity {
        private WebView aktuerp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);
        setContentView(R.layout.activity_aktu__erp);
        aktuerp=(WebView)findViewById(R.id.aktu_erp_web);
        WebSettings webSettings = aktuerp.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDisplayZoomControls(true);
        aktuerp.loadUrl("https://erp.aktu.ac.in/");
        aktuerp.setWebViewClient(new WebViewClient());

    }

    @Override
    public void onBackPressed() {
        if (aktuerp.canGoBack()) {
            aktuerp.goBack();
        }
        else {
            super.onBackPressed();
        }

    }
    }

