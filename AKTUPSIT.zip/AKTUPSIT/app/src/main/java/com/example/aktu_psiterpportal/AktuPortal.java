package com.example.aktu_psiterpportal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;

public class AktuPortal extends AppCompatActivity implements View.OnClickListener {
    ImageButton ov,erp,sp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);
        setContentView(R.layout.activity_aktu_portal);
            ov =  findViewById(R.id.OneView);           //OneView_AKTU_Portal
            erp = findViewById(R.id.ERP);               //ERP_Portal_AKTU
            sp = findViewById(R.id.StudentPortal);      //Student_portal_AKTU


            sp.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent i = new Intent(AktuPortal.this,AKTU_SP.class);
                    startActivity(i);
                }
            });                                     //Listener on Student portal of aktu


            erp.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent i =new Intent(AktuPortal.this,AKTU_ERP.class);
                    startActivity(i);
                }
            });                                 //listener on erp portal of aktu


            ov.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent i = new Intent(AktuPortal.this, OneViewAktu.class);
                    startActivity(i);
                }
            });                             //listener on OneView result site of Aktu

    }

    @Override
    public void onClick(View view) {

    }
}
