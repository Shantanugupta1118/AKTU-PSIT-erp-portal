package com.example.aktu_psiterpportal;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    Button aktu,psit;
   ImageButton ib;
   Boolean doubleTab = false;

    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
       getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);
        ib = (ImageButton)findViewById(R.id.about);
        ib.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick (View view){
                Intent intent = new Intent(MainActivity.this, Option.class);
                startActivity(intent);
            }
        });
        aktu =(Button) findViewById(R.id.aktu);
                                                  //    LISTENER ON AKTU CLICK LISTENER FOR TRANFER TO NEXT PAGE OF AKTU_PORTAL...
        aktu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this,AktuPortal.class);
                startActivity(i);
            }
        });


        psit=findViewById(R.id.psit);
                                                    //  LISTENEE USE FOR TRANSFER DATA DIRECT TO WEB PAGE OF PSIT ERP PORTAL AS PSIT WEB VIEW
        psit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this,PSIT_PORTAL.class);
                startActivity(i);
            }
        });

        Toast.makeText(this, "WELCOME TO AKTU-PSIT ERP PORTAL", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onClick(View view) {

    }

    @Override
    public void onBackPressed() {
        if(doubleTab) {
            super.onBackPressed();
        }
        else {
            Toast.makeText(this, "Press again to exit Portal!", Toast.LENGTH_SHORT).show();
            doubleTab = true;
            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    doubleTab = false;
                }
            },500);         //500 = half Second, 1000 = 1 second......
        }
    }
}
